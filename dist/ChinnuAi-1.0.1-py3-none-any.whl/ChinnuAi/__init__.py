from .KalaQuantum import QuantumState,QuantumTrainer,KalaAI


__version__ = "1.0.1"
